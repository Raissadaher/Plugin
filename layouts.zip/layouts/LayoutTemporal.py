import os
import random
import math

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor, QFont
from qgis.core import *
from qgis.utils import iface
from datetime import date
from qgis.core import QgsLayoutItemScaleBar, QgsProject

class LayoutGeral:
    def __init__(self):
        self.project = QgsProject.instance()
        manager = self.project.layoutManager()
        self.layout = QgsPrintLayout(self.project)
        self.mapa = QgsLayoutItemMap(self.layout)
        self.layoutName = f"pagina_1_{random.randint(1, 500)}"
        self.layout.initializeDefaults()
        self.layout.setName(self.layoutName)
        manager.addLayout(self.layout)
        self.page = QgsLayoutItemPage(self.layout)
        self.page.setPageSize('A4', QgsLayoutItemPage.Landscape)
        self.layout.pageCollection().addPage(self.page)
        iface.openLayoutDesigner(self.layout)


    def executar(self):
        #self.imprime_layers()
        self.adicionando_poligono_maior()
        self.renderizar_mapa01()
        self.renderizar_mapa02()
        self.renderizar_mapa_03()
        self.renderizar_mapa_04()
        self.adicionando_poligono_titulo()
        self.adicionando_subtitulo()
        self.adicionando_tabela()
        self.adicionando_titulo()
        self.barra_de_escala_mapa01()
        self.barra_de_escala_mapa02()
        self.barra_de_escala_mapa03()
        self.barra_de_escala_mapa04()
        self.criando_legenda()
        self.adicionando_grid_mapa01()
        self.adicionando_grid_mapa02()
        self.adicionando_grid_mapa_03()
        self.adicionando_grid_mapa_04()
        self.inserir_car()
        self.inserir_logo()
        self.inserir_norte()
        self.inserindo_texto_mapa_01()
        self.inserindo_texto_mapa_02()
        self.inserindo_texto_mapa_03()
        self.inserindo_texto_mapa_04()

    def imprime_layers(self):
        names = [mapLayers.name() for mapLayers in QgsProject.instance().mapLayers().values()]
        print(names)


    def adicionando_poligono_maior(self):
        rectangle_maior = QgsLayoutItemShape(self.layout)
        rectangle_maior.setShapeType(QgsLayoutItemShape.Rectangle)
        rectangle_maior.setRect(0, 0, 0, 0)
        self.layout.addLayoutItem(rectangle_maior)
        rectangle_maior.attemptMove(QgsLayoutPoint(6, 3, QgsUnitTypes.LayoutMillimeters))
        rectangle_maior.attemptResize(QgsLayoutSize(287.717, 202.350, QgsUnitTypes.LayoutMillimeters))

    def adicionando_poligono_titulo(self):
        rectangle_titulo = QgsLayoutItemShape(self.layout)
        rectangle_titulo.setShapeType(QgsLayoutItemShape.Rectangle)
        rectangle_titulo.setRect(0, 0, 0, 0)
        self.layout.addLayoutItem(rectangle_titulo)
        rectangle_titulo.attemptMove(QgsLayoutPoint(212, 8, QgsUnitTypes.LayoutMillimeters))
        rectangle_titulo.attemptResize(QgsLayoutSize(77, 193.3, QgsUnitTypes.LayoutMillimeters))

    def renderizar_mapa01(self):
        self.mapa01 = QgsLayoutItemMap(self.layout)
        self.mapa01.setAtlasDriven(True)
        self.mapa01.setFrameEnabled(True)
        self.mapa01.setRect(0, 0, 200, 188)
        canvas = iface.mapCanvas()
        self.mapa01.setExtent(canvas.extent())
        self.layout.addLayoutItem(self.mapa01)
        self.mapa01.attemptMove(QgsLayoutPoint(8, 8, QgsUnitTypes.LayoutMillimeters))
        self.mapa01.attemptResize(QgsLayoutSize(99, 94, QgsUnitTypes.LayoutMillimeters))

    def criando_legenda(self):
        legenda = QgsLayoutItemLegend(self.layout)
        legenda.setTitle("Legenda")
        legenda_fonte = QFont("Arial", 11)
        legenda.setStyleFont(QgsLegendStyle.Title, legenda_fonte)
        legenda.setStyleFont(QgsLegendStyle.Subgroup, legenda_fonte)
        legenda.setStyleFont(QgsLegendStyle.SymbolLabel, legenda_fonte)
        legenda.attemptMove(QgsLayoutPoint(212, 90, QgsUnitTypes.LayoutMillimeters))
        legenda.attemptResize(QgsLayoutSize(20, 20, QgsUnitTypes.LayoutMillimeters))
        legenda.setLinkedMap(self.mapa)
        legenda.setItemOpacity(1.0)
        # TODO validar uso de verdadeiro ou falso com numeros
        legenda.setBackgroundEnabled(True)
        #self.legenda.setBackgroundEnabled(0.5)
        legenda.setLegendFilterByMapEnabled(True)
        legenda.refresh()
        self.layout.addLayoutItem(legenda)

    def adicionando_titulo(self):
        layer = self.project.mapLayersByName('Área do imóvel')[0]
        nome = ""
        proprietario = ""
        municipio = ""
        cpf = ""
        wkt = ""

        if layer is not None:
            # Itera sobre as features selecionadas
            for feature in layer.getFeatures():
                nome = feature['nm_imovel']
                proprietario = feature['proprietar']
                cpf = feature['cpf_cnpj']
                municipio = feature['municipio']
                geom = feature.geometry()
                wkt = geom.asWkt(precision=4)

        dados = 'MAPA DE ANÁLISE TEMPORAL' + '\n' 'Propriedade: ' + nome + '\n' + 'Proprietário: ' + proprietario + '\n' + 'CPF/CNPJ: ' + cpf + '\n' + 'Municipio: ' + municipio + '\n' + 'Processo SEI:' + '\n'
        title = QgsLayoutItemLabel(self.layout)
        title.setText(dados)
        title.setFont(QFont("Arial", 10))
        title.adjustSizeToText()
        title.setHAlign(Qt.AlignCenter)
        self.layout.addLayoutItem(title)
        title.attemptResize(QgsLayoutSize(75, 50, QgsUnitTypes.LayoutMillimeters))
        title.attemptMove(QgsLayoutPoint(213, 35, QgsUnitTypes.LayoutMillimeters))


    def adicionando_subtitulo(self):
        dados_propriedade_subtitulo = f"""Sistema Geodésico: Sirgas 2000
        Sistema de coordenada: Projetado-UTM
        Formato: A4
        Escala numérica: 1:{math.floor(self.mapa.scale())}
        Fontes: SEMAD, CAR, MMA, Rede MAIS/MJSP
        Elaboração: Raíssa Daher
        GEGEO / SEMAD-GO
        Data : {date.today().strftime("%d/%m/%Y")}
        """

        subtitle = QgsLayoutItemLabel(self.layout)
        subtitle.setText(dados_propriedade_subtitulo)
        subtitle.setFont(QFont("Arial", 10))
        subtitle.setRect(0, 0, 0, 0)
        subtitle.adjustSizeToText()
        subtitle.setHAlign(Qt.AlignCenter)
        self.layout.addLayoutItem(subtitle)
        subtitle.attemptMove(QgsLayoutPoint(215, 165, QgsUnitTypes.LayoutMillimeters))
        subtitle.attemptResize(QgsLayoutSize(70, 37, QgsUnitTypes.LayoutMillimeters))


    def inserir_norte(self):
        north = QgsLayoutItemPicture(self.layout)
        north.setPicturePath(os.path.join(os.path.dirname(__file__), 'assets', 'norte.svg'))
        self.layout.addLayoutItem(north)
        north.attemptMove(QgsLayoutPoint(240, 70, QgsUnitTypes.LayoutMillimeters))
        north.attemptResize(QgsLayoutSize(20, 20, QgsUnitTypes.LayoutMillimeters))


    def inserir_logo(self):
        logo = QgsLayoutItemPicture(self.layout)
        logo.setPicturePath(os.path.join(os.path.dirname(__file__), 'assets', 'Semad_Abreviada_positivo.png'))
        self.layout.addLayoutItem(logo)
        logo.attemptMove(QgsLayoutPoint(214, 10, QgsUnitTypes.LayoutMillimeters))
        logo.attemptResize(QgsLayoutSize(75, 20.5, QgsUnitTypes.LayoutMillimeters))


    def inserir_car(self):
        area_imovel = self.project.mapLayersByName('Área do imóvel')[0]
        car = ""

        if area_imovel is not None:
            # Itera sobre as features selecionadas
            for feature in area_imovel.getFeatures():
                car = feature['cod_imovel']

        dados = 'CAR: ' + car
        car_layout = QgsLayoutItemLabel(self.layout)
        car_layout.setText(dados)
        car_layout.setFont(QFont("Arial", 7))
        car_layout.adjustSizeToText()
        car_layout.setHAlign(Qt.AlignLeft)
        self.layout.addLayoutItem(car_layout)
        car_layout.attemptResize(QgsLayoutSize(75, 4, QgsUnitTypes.LayoutMillimeters))
        car_layout.attemptMove(QgsLayoutPoint(10, 202, QgsUnitTypes.LayoutMillimeters))


    def adicionando_grid_mapa01(self):
        self.mapa01.grid().setEnabled(True)
        self.mapa01.grid().setUnits(QgsLayoutItemMapGrid.DynamicPageSizeBased)
        self.mapa01.grid().setMaximumIntervalWidth(50)
        self.mapa01.grid().setMinimumIntervalWidth(45)
        self.mapa01.grid().setAnnotationEnabled(True)
        # map.grid().setGridLineColor(QColor(0, 176, 246))
        self.mapa01.grid().setGridLineWidth(0.1)
        self.mapa01.grid().setAnnotationPrecision(0)
        self.mapa01.grid().setAnnotationFrameDistance(1)
        self.mapa01.grid().setAnnotationFontColor(QColor(0, 0, 0))
        # map.grid().setStyle(QgsLayoutItemMapGrid.FrameAnnotationsOnly)
        # map.grid().setStyle(QgsLayoutItemMapGrid.Cross)
        # map.grid().setStyle(QgsLayoutItemMapGrid.Markers)
        self.mapa01.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.HideAll, QgsLayoutItemMapGrid.Right)
        self.mapa01.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.ShowAll, QgsLayoutItemMapGrid.Top)
        self.mapa01.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.HideAll, QgsLayoutItemMapGrid.Bottom)
        self.mapa01.grid().setAnnotationPosition(QgsLayoutItemMapGrid.OutsideMapFrame, QgsLayoutItemMapGrid.Bottom)
        self.mapa01.grid().setAnnotationDirection(QgsLayoutItemMapGrid.Horizontal, QgsLayoutItemMapGrid.Bottom)
        self.mapa01.grid().setAnnotationPosition(QgsLayoutItemMapGrid.OutsideMapFrame, QgsLayoutItemMapGrid.Left)
        self.mapa01.grid().setAnnotationDirection(QgsLayoutItemMapGrid.Vertical, QgsLayoutItemMapGrid.Left)
        self.mapa01.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.ShowAll, QgsLayoutItemMapGrid.Left)

    # Barra de escala mapa 01
    def barra_de_escala_mapa01(self):
        escala01 = QgsLayoutItemScaleBar(self.layout)
        escala01.setStyle('Caixa Simples')
        escala01.setLinkedMap(self.mapa)
        escala01.setHeight(2)
        escala01.setFont(QFont('Arial', 10))
        escala01.applyDefaultSize()
        escala01.attemptMove(QgsLayoutPoint(230, 150, QgsUnitTypes.LayoutMillimeters))
        self.layout.addLayoutItem(escala01)

    def renderizar_mapa02(self):
        self.mapa02 = QgsLayoutItemMap(self.layout)
        self.mapa02.setAtlasDriven(True)
        self.mapa02.setFrameEnabled(True)
        self.mapa02.setRect(0, 0, 200, 188)
        canvas = iface.mapCanvas()
        self.mapa02.setExtent(canvas.extent())
        self.layout.addLayoutItem(self.mapa02)
        self.mapa02.mapa01.attemptMove(QgsLayoutPoint(8, 8, QgsUnitTypes.LayoutMillimeters))
        self.mapa02.mapa01.attemptResize(QgsLayoutSize(99, 94, QgsUnitTypes.LayoutMillimeters))

    # Barra de escala mapa 02
    def barra_de_escala_mapa02(self):
        escala02 = QgsLayoutItemScaleBar(self.layout)
        escala02.setStyle('Caixa Simples')
        escala02.setLinkedMap(self.mapa)
        escala02.setHeight(2)
        escala02.setFont(QFont('Arial', 10))
        escala02.applyDefaultSize()
        escala02.attemptMove(QgsLayoutPoint(230, 150, QgsUnitTypes.LayoutMillimeters))
        self.layout.addLayoutItem(escala02)

    def adicionando_grid_mapa02(self):
        grid = QgsLayoutItemMapGrid("New grid", self.mapa02)
        self.mapa02.grid().setEnabled(True)
        self.mapa02.grid().setUnits(QgsLayoutItemMapGrid.DynamicPageSizeBased)
        # map.grid().setIntervalX(1000)
        # map.grid().setIntervalY(1000)
        self.mapa02.grid().setMaximumIntervalWidth(45)
        self.mapa02.grid().setMinimumIntervalWidth(10)
        self.mapa02.grid().setAnnotationEnabled(True)
        # map.grid().setGridLineColor(QColor(0, 176, 246))
        self.mapa02.grid().setGridLineWidth(0.1)
        self.mapa02.grid().setAnnotationPrecision(0)
        self.mapa02.grid().setAnnotationFrameDistance(0)
        self.mapa02.grid().setAnnotationFontColor(QColor(0, 0, 0))
        self.mapa02.grid().setAnnotationFont(QFont('Arial', 8))
        # map.grid().setStyle(QgsLayoutItemMapGrid.FrameAnnotationsOnly)
        # map.grid().setStyle(QgsLayoutItemMapGrid.Cross)
        # map.grid().setStyle(QgsLayoutItemMapGrid.Markers)
        self.mapa02.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.HideAll, QgsLayoutItemMapGrid.Right)
        self.mapa02.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.ShowAll, QgsLayoutItemMapGrid.Top)
        self.mapa02.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.HideAll, QgsLayoutItemMapGrid.Bottom)
        self.mapa02.grid().setAnnotationPosition(QgsLayoutItemMapGrid.OutsideMapFrame, QgsLayoutItemMapGrid.Bottom)
        self.mapa02.grid().setAnnotationDirection(QgsLayoutItemMapGrid.Horizontal, QgsLayoutItemMapGrid.Bottom)
        self.mapa02.grid().setAnnotationPosition(QgsLayoutItemMapGrid.OutsideMapFrame, QgsLayoutItemMapGrid.Left)
        self.mapa02.grid().setAnnotationDirection(QgsLayoutItemMapGrid.Vertical, QgsLayoutItemMapGrid.Left)
        self.mapa02.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.ShowAll, QgsLayoutItemMapGrid.Left)

    def renderizar_mapa_03(self):
        self.mapa03 = QgsLayoutItemMap(self.layout)
        self.mapa03.setAtlasDriven(True)
        self.mapa03.setFrameEnabled(True)
        self.mapa03.setRect(0, 0, 200, 188)
        canvas = iface.mapCanvas()
        self.mapa03.setExtent(canvas.extent())
        self.layout.addLayoutItem(self.mapa03)
        self.mapa03.attemptMove(QgsLayoutPoint(8, 107, QgsUnitTypes.LayoutMillimeters))
        self.mapa03.attemptResize(QgsLayoutSize(99.699, 94.286, QgsUnitTypes.LayoutMillimeters))

    def barra_de_escala_mapa03(self):
        escala = QgsLayoutItemScaleBar(self.layout)
        escala.setStyle('Caixa Simples')
        escala.setLinkedMap(self.mapa01)
        escala.setHeight(1)
        escala.setLabelBarSpace(1)
        escala.setBoxContentSpace(0.1)
        escala.update()
        escala.setBackgroundEnabled(True)
        escala.setFont(QFont('Arial', 6))
        escala.applyDefaultSize()
        escala.attemptResize(QgsLayoutSize(5, 5, QgsUnitTypes.LayoutMillimeters))
        escala.attemptMove(QgsLayoutPoint(85, 195, QgsUnitTypes.LayoutMillimeters))
        self.layout.addLayoutItem(escala)

    def adicionando_grid_mapa_03(self):
        grid = QgsLayoutItemMapGrid("New grid", self.mapa01)
        self.mapa03.grid().setEnabled(True)
        self.mapa03.grid().setUnits(QgsLayoutItemMapGrid.DynamicPageSizeBased)
        # map.grid().setIntervalX(1000)
        # map.grid().setIntervalY(1000)
        self.mapa03.grid().setMaximumIntervalWidth(45)
        self.mapa03.grid().setMinimumIntervalWidth(10)
        self.mapa03.grid().setAnnotationEnabled(True)
        # map.grid().setGridLineColor(QColor(0, 176, 246))
        self.mapa03.grid().setGridLineWidth(0.1)
        self.mapa03.grid().setAnnotationPrecision(0)
        self.mapa03.grid().setAnnotationFrameDistance(0)
        self.mapa03.grid().setAnnotationFontColor(QColor(0, 0, 0))
        self.mapa03.grid().setAnnotationFont(QFont('Arial', 8))
        # map.grid().setStyle(QgsLayoutItemMapGrid.FrameAnnotationsOnly)
        # map.grid().setStyle(QgsLayoutItemMapGrid.Cross)
        # map.grid().setStyle(QgsLayoutItemMapGrid.Markers)
        self.mapa03.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.HideAll, QgsLayoutItemMapGrid.Right)
        self.mapa03.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.ShowAll, QgsLayoutItemMapGrid.Top)
        self.mapa03.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.HideAll, QgsLayoutItemMapGrid.Bottom)
        self.mapa03.grid().setAnnotationPosition(QgsLayoutItemMapGrid.OutsideMapFrame, QgsLayoutItemMapGrid.Bottom)
        self.mapa03.grid().setAnnotationDirection(QgsLayoutItemMapGrid.Horizontal, QgsLayoutItemMapGrid.Bottom)
        self.mapa03.grid().setAnnotationPosition(QgsLayoutItemMapGrid.OutsideMapFrame, QgsLayoutItemMapGrid.Left)
        self.mapa03.grid().setAnnotationDirection(QgsLayoutItemMapGrid.Vertical, QgsLayoutItemMapGrid.Left)
        self.mapa03.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.ShowAll, QgsLayoutItemMapGrid.Left)

    def renderizar_mapa_04(self):
        self.mapa04 = QgsLayoutItemMap(self.layout)
        self.mapa04.setAtlasDriven(True)
        self.mapa04.setFrameEnabled(True)
        self.mapa04.setRect(0, 0, 200, 188)
        canvas = iface.mapCanvas()
        self.mapa04.setExtent(canvas.extent())
        self.layout.addLayoutItem(self.mapa04)
        self.mapa04.attemptMove(QgsLayoutPoint(110, 107, QgsUnitTypes.LayoutMillimeters))
        self.mapa04.attemptResize(QgsLayoutSize(99.699, 94.286, QgsUnitTypes.LayoutMillimeters))

    def barra_de_escala_mapa04(self):
        escala = QgsLayoutItemScaleBar(self.layout)
        escala.setStyle('Caixa Simples')
        escala.setLinkedMap(self.mapa01)
        escala.setHeight(1)
        escala.setLabelBarSpace(1)
        escala.setBoxContentSpace(0.1)
        escala.update()
        escala.setBackgroundEnabled(True)
        escala.setFont(QFont('Arial', 6))
        escala.applyDefaultSize()
        escala.attemptResize(QgsLayoutSize(5, 5, QgsUnitTypes.LayoutMillimeters))
        escala.attemptMove(QgsLayoutPoint(187, 195, QgsUnitTypes.LayoutMillimeters))
        self.layout.addLayoutItem(escala)

    def adicionando_grid_mapa_04(self):
        grid = QgsLayoutItemMapGrid("New grid", self.mapa01)
        self.mapa04.grid().setEnabled(True)
        self.mapa04.grid().setUnits(QgsLayoutItemMapGrid.DynamicPageSizeBased)
        # map.grid().setIntervalX(1000)
        # map.grid().setIntervalY(1000)
        self.mapa04.grid().setMaximumIntervalWidth(45)
        self.mapa04.grid().setMinimumIntervalWidth(10)
        self.mapa04.grid().setAnnotationEnabled(True)
        # map.grid().setGridLineColor(QColor(0, 176, 246))
        self.mapa04.grid().setGridLineWidth(0.1)
        self.mapa04.grid().setAnnotationPrecision(0)
        self.mapa04.grid().setAnnotationFrameDistance(0)
        self.mapa04.grid().setAnnotationFontColor(QColor(0, 0, 0))
        self.mapa04.grid().setAnnotationFont(QFont('Arial', 8))
        # map.grid().setStyle(QgsLayoutItemMapGrid.FrameAnnotationsOnly)
        # map.grid().setStyle(QgsLayoutItemMapGrid.Cross)
        # map.grid().setStyle(QgsLayoutItemMapGrid.Markers)
        self.mapa04.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.HideAll, QgsLayoutItemMapGrid.Right)
        self.mapa04.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.ShowAll, QgsLayoutItemMapGrid.Top)
        self.mapa04.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.HideAll, QgsLayoutItemMapGrid.Bottom)
        self.mapa04.grid().setAnnotationPosition(QgsLayoutItemMapGrid.OutsideMapFrame, QgsLayoutItemMapGrid.Bottom)
        self.mapa04.grid().setAnnotationDirection(QgsLayoutItemMapGrid.Horizontal, QgsLayoutItemMapGrid.Bottom)
        self.mapa04.grid().setAnnotationPosition(QgsLayoutItemMapGrid.OutsideMapFrame, QgsLayoutItemMapGrid.Left)
        self.mapa04.grid().setAnnotationDirection(QgsLayoutItemMapGrid.Vertical, QgsLayoutItemMapGrid.Left)
        self.mapa04.grid().setAnnotationDisplay(QgsLayoutItemMapGrid.ShowAll, QgsLayoutItemMapGrid.Left)


    def adicionando_tabela(self):
        centroides_gerais = self.project.mapLayersByName('Centroides gerais')[0]
        tabela_atributos = QgsLayoutItemAttributeTable.create(self.layout)
        tabela_atributos.setVectorLayer(centroides_gerais)
        tabela_atributos.setMaximumNumberOfFeatures(40)
        self.layout.addMultiFrame(tabela_atributos)
        frame2 = QgsLayoutFrame(self.layout, tabela_atributos)
        frame2.attemptResize(QgsLayoutSize(198.200, 224), True)
        frame2.attemptMove(QgsLayoutPoint(120, 220, QgsUnitTypes.LayoutMillimeters))
        tabela_atributos.addFrame(frame2)
        # TODO ajustar resize mode
        tabela_atributos.setResizeMode(1)

        coluna = QgsLayoutTableColumn()
        coluna.setAttribute('id')  # First column name in your case. You can also put an expression
        coluna.setSortOrder(0)  # 0 = Asc, 1 Desc
        tabela_atributos.setSortColumns([coluna])
        self.layout.refresh()


    def inserindo_texto_mapa_01(self):
        dados01 = '12/2024'
        map_label = QgsLayoutItemLabel(self.layout)
        map_label.setText(dados01)
        map_label.setFont(QFont("Arial", 9))
        map_label.setItemOpacity(1.0)
        map_label.setBackgroundEnabled(1)
        map_label.adjustSizeToText()
        self.layout.addLayoutItem(map_label)
        map_label.attemptResize(QgsLayoutSize(12, 3, QgsUnitTypes.LayoutMillimeters))
        map_label.attemptMove(QgsLayoutPoint(8.5, 98, QgsUnitTypes.LayoutMillimeters))


    def inserindo_texto_mapa_02(self):
        dados02 = '12/2024'
        map_label = QgsLayoutItemLabel(self.layout)
        map_label.setText(dados02)
        map_label.setFont(QFont("Arial", 9))
        map_label.setItemOpacity(1.0)
        map_label.setBackgroundEnabled(1)
        map_label.adjustSizeToText()
        self.layout.addLayoutItem(map_label)
        map_label.attemptResize(QgsLayoutSize(12, 3, QgsUnitTypes.LayoutMillimeters))
        map_label.attemptMove(QgsLayoutPoint(111, 98, QgsUnitTypes.LayoutMillimeters))


    def inserindo_texto_mapa_03(self):
        dados03 = '12/2024'
        map_label = QgsLayoutItemLabel(self.layout)
        map_label.setText(dados03)
        map_label.setFont(QFont("Arial", 9))
        map_label.setItemOpacity(1.0)
        map_label.setBackgroundEnabled(1)
        map_label.adjustSizeToText()
        self.layout.addLayoutItem(map_label)
        map_label.attemptResize(QgsLayoutSize(12, 3, QgsUnitTypes.LayoutMillimeters))
        map_label.attemptMove(QgsLayoutPoint(8.5, 198, QgsUnitTypes.LayoutMillimeters))


    def inserindo_texto_mapa_04(self):
        dados04 = '12/2024'
        map_label = QgsLayoutItemLabel(self.layout)
        map_label.setText(dados04)
        map_label.setFont(QFont("Arial", 9))
        map_label.setItemOpacity(1.0)
        map_label.setBackgroundEnabled(1)
        map_label.adjustSizeToText()
        self.layout.addLayoutItem(map_label)
        map_label.attemptResize(QgsLayoutSize(12, 3, QgsUnitTypes.LayoutMillimeters))
        map_label.attemptMove(QgsLayoutPoint(111, 198, QgsUnitTypes.LayoutMillimeters))

